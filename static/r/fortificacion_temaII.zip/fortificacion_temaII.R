# Importar datos (para importar un  fichero, nos hace falta saber el camino)
# para crear el objeto dato, nos hace falta importar un archivo que está localizado en un camino 
# la función read_csv 
datos <- read_csv("static/csv/nutricion.csv") 
# note la similitud 
alimimentos <- c("boniato") # solo que aca, read_csv() sustituye a c() y que la cadena de texto boniato es ahora el camino
# simpre puedes copiar el camino de la función file.choose()
file.choose() # es una funcion sin argumentos, que nos dice el camino a cualquier fichero, eje "data/nutricion.csv"
# !LISTO



# Ahora para ver los datos podemos usar dos funciones, que le pasaremos el objeto datos como argumento
View(datos) #  (horizontal)
glimpse(datos)  #  (vertical)

#nota: para usar cualquier función de un paquete que no este en R base, hay que activar el paquete

# script para hacer una tabla con los datos
library(tidyverse) 
library(gtsummary)
datos <- read_csv(file = "static/csv/nutricion.csv") # creo el objeto datos


# Tabla: lo mismo que boniato pero ahora los elementos son diferentes y se les asignan a argumentos dentro de la función 
tbl_summary(data = datos,by = ocupacion ) # ahora es como  c(vianda="platano", hortaliza="chicharos")


# grafico
library(ggstatsplot)

ggbetweenstats(data = datos,y = peso,x = estado_civil )


